# LR0_experiment_harness

Reproducible neural-network experiments with Optuna and MLflow. This submission contains code, configurations, data provenance, preregistered expectations, tests and original experiment artifacts. Reports are intentionally not included and will be submitted separately.

## Environment

Python 3.11; PyTorch CPU; one compute thread. Install exact primary dependencies from requirements.txt. requirements-lock.txt records the runtime dependency closure used on Windows.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Inspect submitted results

Extract artifacts/experiment_results.zip into the repository root. It contains the 57 formal runs, the 40-trial Optuna study, MLflow tracking database, raw run attachments and the two-session search record. No report documents or figures are included. Verify the archive SHA-256 using artifacts/manifest.json.

```powershell
python -m unittest discover -s tests -v
python verify_results.py --final
python relocate_mlflow.py
python -m mlflow ui --backend-store-uri sqlite:///mlflow.db --host 127.0.0.1 --port 5001
```

Use the configured Python/virtual environment for these commands. In MLflow select LR0_experiment_harness. Relocation backs up the database before updating attachment paths. Do not commit the extracted databases or run directories; .gitignore excludes them.

## Experiment protocol

load_digits has 1797 images. Stratified split_seed=0 produces 1077 training, 360 validation and 360 test images. Features are divided by 16. MLP uses ReLU/dropout, Adam and 30 epochs.

1. Repeat base seed 0 twice, then run base seeds 1-5.
2. Perform 40 sequential Optuna trials with TPE(seed=42) and MedianPruner(startup=5, warmup=5), pausing after 10 trials and resuming to 40.
3. Select the best configuration using validation accuracy only and commit it before final evaluation. Compare base/best using seeds 101-105.

This is a fresh execution of a previously used fixed protocol, not a newly unseen test split. No search or selection rule was changed using the previous test results. The pre-run expectations are in forecast.md. Real epoch times differ even when deterministic losses and predictions match.

## Run a new experiment

Use an independent directory with no previous run directories/databases. The included selected configuration already belongs to the submitted run; archive it and commit the new protocol before selecting another configuration. See prepare_data.py, run_series.py, search.py and select_best.py. Final runs require a clean Git working tree. Test evaluation is reserved for the final series.

The training implementation is shared by train.py and Optuna. analyze.py and render_reports.py are generation tools; report outputs are excluded from this publication branch. Code was generated with Codex assistance and checked using unit tests, repeatability checks and independent recomputation from per-image results.

## History

The first two commits preserve the original pre-run protocol and validation-based selection, including the hashes referenced by the submitted metadata. Later report-only history is not published on this branch.
