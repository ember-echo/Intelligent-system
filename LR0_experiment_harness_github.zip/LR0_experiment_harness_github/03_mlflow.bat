@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if errorlevel 1 exit /b 1
set "LAB_PY=python"
if exist "%~dp0.venv\Scripts\python.exe" set "LAB_PY=%~dp0.venv\Scripts\python.exe"
set "PYTHONIOENCODING=utf-8"
set "MLFLOW_DISABLE_AGENT_HINT=1"
echo Open http://127.0.0.1:5001 after startup.
"%LAB_PY%" -m mlflow ui --backend-store-uri sqlite:///mlflow.db --host 127.0.0.1 --port 5001 --workers 1
pause
